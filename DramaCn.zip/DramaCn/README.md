# Drama CN — Android + backend starter

Project starter Android Kotlin/Jetpack Compose + Media3 ExoPlayer, Node.js scraper API, dan GitHub Actions.

## Build APK di GitHub
1. Upload seluruh isi ZIP ke root repository GitHub (jangan letakkan di subfolder).
2. Buka tab **Actions** → **Build Drama CN APK** → **Run workflow**.
3. Unduh artifact `Drama-CN-debug` setelah workflow selesai.
4. APK debug dapat dipasang untuk pengujian. Untuk distribusi publik, buat signing key sendiri dan tambahkan signing release yang aman melalui GitHub Secrets.

## Hubungkan backend
- Deploy folder `backend` ke server HTTPS.
- Ikuti `backend/README.md` untuk mengatur sumber yang Anda miliki/diizinkan.
- Ganti `BASE_URL` pada `app/src/main/java/com/dramacn/app/Api.kt` dengan URL backend HTTPS (wajib trailing slash), lalu build ulang.

## Batasan penting
- ZIP ini adalah starter yang bisa dikembangkan, bukan katalog drama siap pakai. Tidak ada sumber video pihak ketiga yang disertakan.
- Scraper generik hanya mengambil metadata katalog berdasarkan selector yang Anda konfigurasi. Struktur detail episode dan stream berbeda antar situs; adapter episode perlu dibuat per sumber yang sah.
- Pemutaran HLS/MP4 memakai Media3. Download saat ini dibatasi ke URL HTTPS MP4 langsung yang ditandai `downloadable=true`; HLS download belum diimplementasikan.
- Jangan scraping atau mengunduh konten tanpa izin, melewati DRM, paywall, login, atau proteksi teknis. Gunakan API resmi atau sumber yang memberi izin.
- Aplikasi menampilkan data demo bila backend belum tersambung.
