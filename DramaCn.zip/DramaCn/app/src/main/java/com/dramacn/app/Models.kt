package com.dramacn.app

data class Drama(
    val id: String,
    val title: String,
    val description: String = "",
    val poster: String = "",
    val category: String = "Short Drama",
    val episodes: List<Episode> = emptyList()
)
data class Episode(
    val id: String,
    val title: String,
    val streamUrl: String,
    val subtitleUrl: String? = null,
    val downloadable: Boolean = false
)
data class CatalogResponse(val items: List<Drama> = emptyList())
