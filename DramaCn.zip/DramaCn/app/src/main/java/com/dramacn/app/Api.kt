package com.dramacn.app

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

interface DramaApi {
    @GET("api/catalog")
    suspend fun catalog(@Query("q") query: String = "", @Query("source") source: String = ""): CatalogResponse

    companion object {
        // Change to your deployed HTTPS backend URL. Keep trailing slash.
        const val BASE_URL = "https://YOUR_BACKEND_DOMAIN/"
        fun create(): DramaApi = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build().create(DramaApi::class.java)
    }
}
