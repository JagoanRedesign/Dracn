package com.dramacn.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import android.app.DownloadManager
import android.os.Environment

private val Bg = Color(0xFF090B12)
private val Panel = Color(0xFF171B27)
private val Accent = Color(0xFFFF4668)

class MainActivity : ComponentActivity() {
    private val api by lazy { DramaApi.create() }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DramaApp() }
    }

    @Composable private fun DramaApp() {
        var dramas by remember { mutableStateOf(sampleDramas()) }
        var selected by remember { mutableStateOf<Drama?>(null) }
        var query by remember { mutableStateOf("") }
        var loading by remember { mutableStateOf(false) }
        var error by remember { mutableStateOf("") }

        MaterialTheme(colorScheme = darkColorScheme(
            primary = Accent, background = Bg, surface = Panel,
            onBackground = Color.White, onSurface = Color.White
        )) {
            Surface(Modifier.fillMaxSize(), color = Bg) {
                Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
                    Row(Modifier.fillMaxWidth().padding(top = 22.dp, bottom = 14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text("DRAMA CN", color = Accent, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                            Text("Short Drama", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold)
                        }
                        Icon(Icons.Default.Movie, contentDescription = null, tint = Accent, modifier = Modifier.size(34.dp))
                    }
                    OutlinedTextField(value = query, onValueChange = { query = it },
                        modifier = Modifier.fillMaxWidth(), placeholder = { Text("Cari drama...") },
                        leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true,
                        shape = RoundedCornerShape(16.dp))
                    Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AssistChip(onClick = { selected = null }, label = { Text("Untuk kamu") })
                        AssistChip(onClick = { loadCatalog(query, { dramas = it; error = "" }, { error = it }, { loading = it }) }, label = { Text("Refresh") })
                    }
                    if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
                    if (error.isNotBlank()) Text(error, color = Color(0xFFFFA0A0), modifier = Modifier.padding(8.dp))
                    if (selected == null) {
                        Text("Pilihan drama", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(vertical = 8.dp))
                        LazyVerticalGrid(columns = GridCells.Fixed(2), contentPadding = PaddingValues(bottom = 24.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                            items(dramas.filter { it.title.contains(query, true) || query.isBlank() }) { drama ->
                                Column(Modifier.background(Panel, RoundedCornerShape(16.dp)).clickable { selected = drama }.padding(8.dp)) {
                                    AsyncImage(model = drama.poster.ifBlank { null }, contentDescription = drama.title,
                                        modifier = Modifier.fillMaxWidth().height(190.dp).background(Color(0xFF282D3B), RoundedCornerShape(12.dp)))
                                    Text(drama.title, fontWeight = FontWeight.Bold, maxLines = 2, modifier = Modifier.padding(top = 8.dp))
                                    Text(drama.category, color = Color.LightGray, style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                    } else {
                        val drama = selected!!
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { selected = null }) { Icon(Icons.Default.ArrowBack, null) }
                            Text("Detail drama", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        }
                        AsyncImage(model = drama.poster.ifBlank { null }, contentDescription = null,
                            modifier = Modifier.fillMaxWidth().height(210.dp).background(Panel, RoundedCornerShape(16.dp)))
                        Text(drama.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(top = 12.dp))
                        Text(drama.description.ifBlank { "Sinopsis belum tersedia." }, color = Color.LightGray,
                            modifier = Modifier.padding(vertical = 8.dp))
                        Text("Daftar episode", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        androidx.compose.foundation.lazy.LazyColumn {
                            items(drama.episodes.size) { index ->
                                val ep = drama.episodes[index]
                                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp).background(Panel, RoundedCornerShape(12.dp)).padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(ep.title, fontWeight = FontWeight.SemiBold)
                                        Text("Streaming tersedia", color = Color.LightGray, style = MaterialTheme.typography.labelSmall)
                                    }
                                    IconButton(onClick = { play(ep) }) { Icon(Icons.Default.PlayArrow, null, tint = Accent) }
                                    if (ep.downloadable) IconButton(onClick = { download(ep) }) {
                                        Icon(Icons.Default.Download, null, tint = Color.White)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private fun loadCatalog(q: String, success: (List<Drama>) -> Unit, fail: (String) -> Unit, busy: (Boolean) -> Unit) {
        lifecycleScope.launch {
            busy(true)
            try { success(api.catalog(q).items) }
            catch (e: Exception) { fail("Backend belum terhubung. Atur BASE_URL di Api.kt. Menampilkan data demo.") }
            finally { busy(false) }
        }
    }
    private fun play(ep: Episode) {
        if (ep.streamUrl.isBlank()) { Toast.makeText(this, "URL video belum tersedia", Toast.LENGTH_SHORT).show(); return }
        startActivity(Intent(this, PlayerActivity::class.java).putExtra("url", ep.streamUrl).putExtra("title", ep.title))
    }
    private fun download(ep: Episode) {
        if (!ep.downloadable || !ep.streamUrl.startsWith("https://") || !ep.streamUrl.substringBefore("?").endsWith(".mp4")) {
            Toast.makeText(this, "Download hanya untuk MP4 HTTPS yang diizinkan.", Toast.LENGTH_LONG).show(); return
        }
        try {
            val request = DownloadManager.Request(Uri.parse(ep.streamUrl))
                .setTitle(ep.title).setDescription("Drama CN")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "DramaCn_${ep.id}.mp4")
            (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
        } catch (_: Exception) { Toast.makeText(this, "Download gagal", Toast.LENGTH_SHORT).show() }
    }
}

private fun sampleDramas() = listOf(
    Drama("demo-1", "CEO Rahasia dan Cinta", "Contoh katalog. Hubungkan backend untuk konten sebenarnya.", "", "Romance",
        listOf(Episode("demo-1-1", "Episode 1", ""), Episode("demo-1-2", "Episode 2", ""))),
    Drama("demo-2", "Balas Dendam Sang Pewaris", "Data demo aplikasi Drama CN.", "", "Short Drama",
        listOf(Episode("demo-2-1", "Episode 1", "")))
)
