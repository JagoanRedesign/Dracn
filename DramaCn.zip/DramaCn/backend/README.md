# Drama CN backend scraper

Backend API untuk metadata katalog dari situs yang Anda miliki atau secara eksplisit mengizinkan scraping. Ini bukan daftar sumber video bajakan dan tidak melewati login, paywall, DRM, token, atau proteksi akses.

## Menjalankan
1. `cd backend && npm install`
2. Salin `sources.example.json` menjadi `sources.json`.
3. Ubah `baseUrl`, path, dan selector sesuai dokumentasi/izin sumber Anda.
4. Buat `.env` dari `.env.example`, lalu isi `ALLOWED_HOSTS` dengan hostname yang diizinkan.
5. `npm start`

Endpoint: `GET /health`, `GET /api/sources`, `GET /api/catalog?q=...`.

Untuk menambahkan episode, buat adapter detail khusus untuk sumber yang diizinkan dan kembalikan metadata episode dengan URL stream yang memang disediakan untuk pemutaran. Gunakan HTTPS. Validasi host untuk semua URL gambar dan stream sebelum mengirim ke aplikasi.
