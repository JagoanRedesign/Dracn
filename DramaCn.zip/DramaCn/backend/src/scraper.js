import * as cheerio from 'cheerio';

function safeUrl(raw, base, allowedHosts) {
  const u = new URL(raw, base);
  if (u.protocol !== 'https:' || !allowedHosts.has(u.hostname)) throw new Error('URL host/protocol tidak diizinkan');
  return u.toString();
}
async function fetchHtml(url) {
  const response = await fetch(url, {
    headers: { 'User-Agent': 'DramaCN/1.0 (+contact site owner; authorized catalog metadata client)' },
    signal: AbortSignal.timeout(12000)
  });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  return response.text();
}
export async function scrapeCatalog(source, allowedHosts) {
  const catalogUrl = safeUrl(source.catalogPath, source.baseUrl, allowedHosts);
  const html = await fetchHtml(catalogUrl);
  const $ = cheerio.load(html);
  const out = [];
  $(source.selectors.item).each((i, el) => {
    const node = $(el);
    const title = node.find(source.selectors.title).first().text().trim();
    const posterRaw = node.find(source.selectors.poster).first().attr('data-src')
      || node.find(source.selectors.poster).first().attr('src') || '';
    const href = node.find(source.selectors.link).first().attr('href') || '';
    if (!title || !href) return;
    let detailUrl;
    try { detailUrl = safeUrl(href, source.baseUrl, allowedHosts); } catch { return; }
    let poster = '';
    if (posterRaw) { try { poster = safeUrl(posterRaw, source.baseUrl, allowedHosts); } catch {} }
    out.push({
      id: `${source.id}-${i}`,
      title,
      description: node.find(source.selectors.description || '.description').first().text().trim(),
      poster,
      category: 'Short Drama',
      detailUrl,
      episodes: []
    });
  });
  return out;
}
// Add a source-specific detail/episode adapter only for pages you own or are licensed to access.
// Never attempt DRM bypass, token theft, paywall circumvention, or extraction of protected streams.
