import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { scrapeCatalog } from './scraper.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
app.use(helmet());
app.use(cors({ origin: process.env.CORS_ORIGIN?.split(',') || '*' }));
app.use(express.json({ limit: '32kb' }));
const port = Number(process.env.PORT || 3000);
const configPath = process.env.SOURCES_FILE || path.resolve(__dirname, '../sources.json');

function loadSources() {
  if (!fs.existsSync(configPath)) return [];
  return JSON.parse(fs.readFileSync(configPath, 'utf8'));
}
app.get('/health', (_req, res) => res.json({ ok: true, app: 'Drama CN API' }));
app.get('/api/sources', (_req, res) => {
  res.json({ sources: loadSources().map(({ id, name }) => ({ id, name })) });
});
app.get('/api/catalog', async (req, res) => {
  try {
    const q = String(req.query.q || '').slice(0, 100).toLowerCase();
    const sourceId = String(req.query.source || '');
    const sources = loadSources().filter(s => !sourceId || s.id === sourceId);
    const allowed = new Set((process.env.ALLOWED_HOSTS || '').split(',').map(x => x.trim()).filter(Boolean));
    const items = [];
    for (const source of sources) {
      if (!allowed.has(new URL(source.baseUrl).hostname)) continue;
      const result = await scrapeCatalog(source, allowed);
      items.push(...result.filter(x => !q || x.title.toLowerCase().includes(q)));
    }
    res.json({ items });
  } catch (e) {
    console.error(e);
    res.status(502).json({ error: 'Scraper gagal. Periksa konfigurasi sumber dan selector.' });
  }
});
app.listen(port, () => console.log(`Drama CN API listening on ${port}`));
